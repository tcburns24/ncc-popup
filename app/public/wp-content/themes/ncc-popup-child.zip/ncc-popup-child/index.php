<?php get_header(); ?>

<main>
    <h1>Hello from NCC Popup Child Theme</h1>
    <p>If you're seeing this, your custom index.php is now working!</p>
</main>

<?php get_footer(); ?>
