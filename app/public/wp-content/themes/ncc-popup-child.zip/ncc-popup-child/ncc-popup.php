<div id="ncc-popup-overlay"></div>
<div id="ncc-popup-form">
  <button id="ncc-close-popup">×</button>
  <button id="ncc-popup-trigger" class="ncc-button">
    Send Me More Information
  </button>

  <form id="ncc-contact-form">
    <input type="text" name="first_name" placeholder="First Name" required />
    <input type="text" name="last_name" placeholder="Last Name" required />
    <input type="email" name="email_address" placeholder="Email Address" required />
    <button type="submit">Submit</button>
    <div id="ncc-form-message"></div>
  </form>
</div>
