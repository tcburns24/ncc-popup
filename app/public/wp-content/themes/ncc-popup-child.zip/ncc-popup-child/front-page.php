<?php
get_header();
?>
<main>
    <h1>Contact Form</h1>
    <div class="sub-header">Nursing CE Central Figure-It-Out Challenge</div>
    <div>
     <button id="ncc-open-popup">Open Contact Form</button>
    </div>
      <div id="ncc-popup-overlay" class="ncc-hidden">
        <div id="ncc-popup-form-wrapper">
          <div class="form-instruction form-row">Submit a new contact</div>
          <form id="ncc-contact-form" style="display: block;">
            <div class="form-row">
              <label>First Name:
                <input type="text" name="first_name" required>
              </label>
            </div>
            <div class="form-row">
              <label>Last Name:
                <input type="text" name="last_name" required>
              </label>
            </div>
            <div class="form-row">
              <label>Email:
                <input type="email" name="email_address" required>
              </label>
            </div>
            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
    <div id="ncc-popup-message" style="display:none;"></div>
</main>
<?php
get_footer();
